FIXED MAA LOVE WEBSITE
Password: us4ever

Replace the old index.html in your GitHub repository with this new index.html, then commit the change to main. Wait briefly and refresh your GitHub Pages website.
